GLASSTOWN NBP
made by Nate Halley
using FontStruct
Version 1.3
Date: 6 November 2012

DESCRIPTION
===========
Based on the bitmap font from The Urbz: Sims in the City for GBA/DS. This is most likely the most unnecessarily jampacked pixel font you'll ever download in your entire life.

CHANGES FROM VERSION 1.2
========================
-Added about a 100 new characters! Now contains Hiragana and Bopomofo.

CHARACTERS INCLUDED
===================
-Basic Latin (QWERTY/AZERTY keyboard)
-Extended Latin (accented characters & symbols)
-Cyrillic
-Greek/Coptic
-Bopomofo
-Hiragana
-Katakana

LICENSE
=======
Glasstown is Creative Commons (by-sa) Attribution Share Alike. That means it's free to download and use. You can also upload it to another website but only as long as you give me credit for making it. You can even make changes to it as long as you give me credit for making the first version and license your new version as CC-BY-SA too.
For more information, go to:
http://creativecommons.org/licenses/by-sa/3.0/

A REQUEST FROM NATE547
======================
Once you install this font, find 2 ways to make the world, the country, your home state/province/county, or your hometown better than it is. Even if it's just recycling your newspaper instead of tossing it on the rubbish.

If you're upgrading from a previous version of this font, find 2 ways you contribute to global de-evolution (like letting Big Business or peer pressure influence your choices or believing outlandish gossip about people without verifying it first) and take steps to change.

Of course, you're not obligated by law to do this.... it's just a request from a Sensible Human who wants our world to change.

Duty now for the future.

Nate547 (Total FontGeek)